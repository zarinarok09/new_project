package com.example.твое_приложение.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.твое_приложение.R
import com.example.твое_приложение.data.models.Product
import com.example.твое_приложение.ui.adapters.ProductAdapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Пример списка товаров
        val productList = listOf(
            Product(1, "Ноутбук ASUS", 75000.0),
            Product(2, "Смартфон Samsung", 40000.0),
            Product(3, "Наушники Sony", 8000.0)
        )

        recyclerView.adapter = ProductAdapter(productList)
    }
}

