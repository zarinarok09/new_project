package com.example.myapplication.ui

class adapters {
}