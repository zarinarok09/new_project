package com.example.твое_приложение.data.models

data class Product(
    val id: Int,
    val name: String,
    val price: Double
)
