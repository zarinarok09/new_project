package com.example.myapplication.viewmodel

class MainViewModel {
}