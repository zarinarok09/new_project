package com.example.myapplication.data

class database {
}