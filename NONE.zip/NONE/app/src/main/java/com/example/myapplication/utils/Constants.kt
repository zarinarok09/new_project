package com.example.myapplication.utils

class Constants {
}